package com.klef.jfsd.springboot.project.service;

import com.klef.jfsd.springboot.project.model.Project;

public interface ProjectService 
{
	public Project addproject(Project project);
}
