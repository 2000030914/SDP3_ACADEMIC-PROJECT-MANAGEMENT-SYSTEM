package com.klef.jfsd.springboot.project.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;


import com.klef.jfsd.springboot.project.model.Team;

public interface TeamRepository extends CrudRepository<Team, Integer>
{
		@Query("select t from Team t where student1=? or student2=? or student3=?")
		public Team checkteamregistration(String student1,String student2,String student3);
}
